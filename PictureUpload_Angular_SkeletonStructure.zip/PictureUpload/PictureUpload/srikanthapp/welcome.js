﻿(function () {
    'use strict';

    angular
        .module('srikanthapp')
        .controller('welcome', welcome);

    function welcome() {
        var vm = this;

        activate();

        function activate() { }
    }
})();
