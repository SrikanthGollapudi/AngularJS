﻿(function () {
    'use strict';

    angular
        .module('srikanthapp.sriphoto')
        .controller('photos', photos);


    function photos() {
        /* jshint validthis:true */
        var vm = this;
        vm.title = 'srikanth gollapudi - photo manager';

    }
})();
