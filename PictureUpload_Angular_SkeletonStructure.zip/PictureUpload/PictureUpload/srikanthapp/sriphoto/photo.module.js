﻿(function () {
    'use strict';

    angular.module('srikanthapp.sriphoto', []);
})();