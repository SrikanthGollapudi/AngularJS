﻿using System.Web;
using System.Web.Optimization;

namespace PictureUpload
{
    public class BundleConfig
    {
        // For more information on bundling, visit http://go.microsoft.com/fwlink/?LinkId=301862
        public static void RegisterBundles(BundleCollection bundles)
        {
            bundles.Add(new ScriptBundle("~/bundles/jquery").Include(
                        "~/Scripts/jquery-{version}.js"));

            bundles.Add(new ScriptBundle("~/bundles/jqueryval").Include(
                        "~/Scripts/jquery.validate*"));

            // Use the development version of Modernizr to develop with and learn from. Then, when you're
            // ready for production, use the build tool at http://modernizr.com to pick only the tests you need.
            bundles.Add(new ScriptBundle("~/bundles/modernizr").Include(
                        "~/Scripts/modernizr-*"));

            bundles.Add(new ScriptBundle("~/bundles/bootstrap").Include(
                      "~/Scripts/bootstrap.js",
                      "~/Scripts/respond.js"));

            bundles.Add(new StyleBundle("~/Content/css").Include(
                      "~/Content/bootstrap.css",
                      "~/Content/site.css"));


            bundles.Add(new ScriptBundle("~/bundles/srikanthapp").Include(
                    "~/Scripts/bootstrap.js",
                    "~/Scripts/respond.js",
                    "~/Scripts/jquery-{version}.js",
                    "~/Scripts/angular.js",
                    "~/Scripts/angular-resource.js",
                    "~/Scripts/angular-route.js",
                    "~/srikanthapp/srikanthapp.js",
                    "~/srikanthapp/appInfo.js",
                    "~/srikanthapp/welcome.js",
                    "~/srikanthapp/egAppStatus.js",
                    "~/srikanthapp/sriphoto/photo.module.js",
                    "~/srikanthapp/sriphoto/photos.js",
                    "~/srikanthapp/sriphoto/photoManager.js",
                    "~/srikanthapp/sriphoto/egAddPhoto.js",
                    "~/srikanthapp/sriphoto/egFiles.js",
                    "~/srikanthapp/sriphoto/egUpload.js",
                    "~/srikanthapp/sriphoto/egPhotoUploader.js",
                    "~/srikanthapp/sriphoto/photoManagerClient.js")); 
        }
    }
}
