﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(PictureUpload.Startup))]
namespace PictureUpload
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
